//1 - Invocamos a Express
const express = require('express');
const cors = require("cors");
const crypto = require('crypto')


const app = express();

//2 - Para poder capturar los datos del formulario (sin urlencoded nos devuelve "undefined")
app.use(express.urlencoded({extended:false}));
app.use(express.json());//además le decimos a express que vamos a usar json
app.use(cors());

//3 - Invocamos a dotenv
const dotenv = require('dotenv');
dotenv.config({ path: './env/.env'});

//4 - Seteamos el directorio de assets
app.use('/resources',express.static('public'));
app.use('/resources', express.static(__dirname + '/public'));

//5 - Establecemos el motor de plantillas
app.set('view engine','ejs');

//6 - Invocamos a bcrypt
const bcrypt = require('bcryptjs');

//7 - Variables de session
const session = require('express-session');
app.use(session({
	secret: 'secret',
	resave: true,
	saveUninitialized: true
}));


//8 - Invocamos a la conexion de la DB
const connection = require('./database/db');

//9 - Establecemos las rutas
app.get('/', (req, res)=> {
	if (req.session.loggedin) {
		res.render('index_out',{
			login: true,
			name: req.session.name,
			rol: req.session.rol
		});		
	} else {
		res.render('index',{
			login:false,
		});				
	}
	res.end();
});

app.get('/login',(req, res)=>{
	if (req.session.loggedin) {
		if (req.session.rol=='admin' || req.session.rol=='data entry'){
			res.render('links',{
				login: true,
				name: req.session.name,
				rol: req.session.rol		
			})
		}else {
			res.render('links2',{
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		}		
	} else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})

app.get('/start',(req, res)=>{
	if (req.session.loggedin) {
		if (req.session.rol=='admin' || req.session.rol=='data entry'){
			res.render('start',{
				login: true,
				name: req.session.name,
				rol: req.session.rol		
			})
		}else {
			res.render('links2',{
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		}		
	} else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})

app.get('/register',(req, res)=>{
	if (req.session.loggedin) {
		if (req.session.rol=='admin'){
			res.render('register',{
				login: true,
				name: req.session.name,
				rol: req.session.rol		
			})
		}else if (req.session.rol=='data entry') {
			res.render('links',{
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		}else {
			res.render('links2',{
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		}		
	}else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})
app.get('/logoutask', (req, res)=>{
	if (req.session.loggedin) {
		res.render('logoutask',{
			login: true,
			name: req.session.name,
			rol: req.session.rol
		});		
	} else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})

app.get('/mesa1',(req, res)=>{
	if (req.session.loggedin) {
		if (req.session.rol=='admin' || req.session.rol=='data entry'){
			res.render('mesa1',{
				login: true,
				name: req.session.name,
				rol: req.session.rol		
			})
		}else {
			res.render('links2',{
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		}		
	} else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})

app.get('/mesa2',(req, res)=>{
	if (req.session.loggedin) {
		if (req.session.rol=='admin' || req.session.rol=='data entry'){
			res.render('mesa2',{
				login: true,
				name: req.session.name,
				rol: req.session.rol		
			})
		}else {
			res.render('links2',{
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		}		
	} else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})

app.get('/mesa3',(req, res)=>{
	if (req.session.loggedin) {
		if (req.session.rol=='admin' || req.session.rol=='data entry'){
			res.render('mesa3',{
				login: true,
				name: req.session.name,
				rol: req.session.rol		
			})
		}else {
			res.render('links2',{
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		}		
	} else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})

app.get('/mesa4',(req, res)=>{
	if (req.session.loggedin) {
		if (req.session.rol=='admin' || req.session.rol=='data entry'){
			res.render('mesa4',{
				login: true,
				name: req.session.name,
				rol: req.session.rol		
			})
		}else {
			res.render('links2',{
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		}		
	} else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})

app.get('/mesa5',(req, res)=>{
	if (req.session.loggedin) {
		if (req.session.rol=='admin' || req.session.rol=='data entry'){
			res.render('mesa5',{
				login: true,
				name: req.session.name,
				rol: req.session.rol		
			})
		}else {
			res.render('links2',{
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		}		
	} else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})

app.get('/mesa6',(req, res)=>{
	if (req.session.loggedin) {
		if (req.session.rol=='admin' || req.session.rol=='data entry'){
			res.render('mesa6',{
				login: true,
				name: req.session.name,
				rol: req.session.rol		
			})
		}else {
			res.render('links2',{
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		}		
	} else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})

app.get('/mesa7',(req, res)=>{
	if (req.session.loggedin) {
		if (req.session.rol=='admin' || req.session.rol=='data entry'){
			res.render('mesa7',{
				login: true,
				name: req.session.name,
				rol: req.session.rol		
			})
		}else {
			res.render('links2',{
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		}		
	} else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})

app.get('/mesa8',(req, res)=>{
	if (req.session.loggedin) {
		if (req.session.rol=='admin' || req.session.rol=='data entry'){
			res.render('mesa8',{
				login: true,
				name: req.session.name,
				rol: req.session.rol		
			})
		}else {
			res.render('links2',{
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		}		
	} else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})

app.get('/mesa9',(req, res)=>{
	if (req.session.loggedin) {
		if (req.session.rol=='admin' || req.session.rol=='data entry'){
			res.render('mesa9',{
				login: true,
				name: req.session.name,
				rol: req.session.rol		
			})
		}else {
			res.render('links2',{
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		}		
	} else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})

app.get('/mesa10',(req, res)=>{
	if (req.session.loggedin) {
		if (req.session.rol=='admin' || req.session.rol=='data entry'){
			res.render('mesa10',{
				login: true,
				name: req.session.name,
				rol: req.session.rol		
			})
		}else {
			res.render('links2',{
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		}		
	} else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})

app.get('/mesa11',(req, res)=>{
	if (req.session.loggedin) {
		if (req.session.rol=='admin' || req.session.rol=='data entry'){
			res.render('mesa11',{
				login: true,
				name: req.session.name,
				rol: req.session.rol		
			})
		}else {
			res.render('links2',{
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		}		
	} else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})

app.get('/mesa12',(req, res)=>{
	if (req.session.loggedin) {
		if (req.session.rol=='admin' || req.session.rol=='data entry'){
			res.render('mesa12',{
				login: true,
				name: req.session.name,
				rol: req.session.rol		
			})
		}else {
			res.render('links2',{
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		}		
	} else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})

app.get('/mesa13',(req, res)=>{
	if (req.session.loggedin) {
		if (req.session.rol=='admin' || req.session.rol=='data entry'){
			res.render('mesa13',{
				login: true,
				name: req.session.name,
				rol: req.session.rol		
			})
		}else {
			res.render('links2',{
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		}		
	} else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})

app.get('/spectator',(req, res)=>{
	if (req.session.loggedin) {
		if (req.session.rol=='admin' || req.session.rol=='data entry' || req.session.rol=='spectator'){
			res.render('spectator',{
				login: true,
				name: req.session.name,
				rol: req.session.rol		
			})
		}else {
			res.render('links2',{
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		}		
	} else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})

app.get('/dashboard',(req, res)=>{
	if (req.session.loggedin) {
		if (req.session.rol=='admin' || req.session.rol=='data entry'){
			res.render('dashboard',{
				login: true,
				name: req.session.name,
				rol: req.session.rol		
			})
		}else {
			res.render('links2',{
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		}		
	} else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})

app.get('/links',(req, res)=>{
	if (req.session.loggedin) {
		if (req.session.rol=='admin') {
			res.render('links',{
				login: true,
				name: req.session.name,
				rol: req.session.rol		
			})
		} else if(req.session.rol=='data entry') {
			res.render('start', {
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		} else {
			res.render('links2',{
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		}		
	} else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})

app.get('/radio',(req, res)=>{
	if (req.session.loggedin) {
		if (req.session.rol=='admin' || req.session.rol=='data entry' || req.session.rol=='radio'){
			res.render('radio',{
				login: true,
				name: req.session.name,
				rol: req.session.rol		
			})
		}else {
			res.render('links2',{
				login: true,
				name: req.session.name,
				rol: req.session.rol
			})
		}		
	} else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})
app.get('/links2',(req, res)=>{
	if (req.session.loggedin) {
		res.render('links2',{
			login: true,
			name: req.session.name,
			rol: req.session.rol		
		})
	} else {
		res.render('login',{
			login:false,
		});				
	}
	res.end();
})

//10 - Método para la REGISTRACIÓN
app.post('/register', async (req, res)=>{
	const user = req.body.user;
	const name = req.body.name;
    const rol = req.body.rol;
	const pass = req.body.pass;
	let passwordHash = await bcrypt.hash(pass, 8);
    connection.query('INSERT INTO users SET ?',{user:user, name:name, rol:rol, pass:passwordHash}, async (error, results)=>{
        if(error){
            console.log(error);
        }else{            
			res.render('register', {
				alert: true,
				alertTitle: "Registration",
				alertMessage: "¡Successful Registration!",
				alertIcon:'success',
				showConfirmButton: false,
				timer: 1500,
				ruta: 'register'
			});
            //res.redirect('/');         
        }
	});
})
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------


//11 - Método para la autenticacion
app.post('/auth', async (req, res)=> {
	const user = req.body.user;
	const pass = req.body.pass;    
    let passwordHash = await bcrypt.hash(pass, 8);
	if (user && pass) {
		connection.query('SELECT * FROM users WHERE user = ?', [user], async (error, results, fields)=> {
			if( results.length == 0 || !(await bcrypt.compare(pass, results[0].pass)) ) {    
				res.render('login', {
                        alert: true,
                        alertTitle: "Error",
                        alertMessage: "USUARIO y/o PASSWORD incorrectas",
                        alertIcon:'error',
                        showConfirmButton: true,
                        timer: false,
                        ruta: 'login'    
                    });
				
				//Mensaje simple y poco vistoso
                //res.send('Incorrect Username and/or Password!');				
			} else {         
				//Creamos una var de session y le asignamos true si INICIÓ SESSION       
				req.session.loggedin = true;                
				req.session.name = results[0].name;
				req.session.rol = results[0].rol;
				if(req.session.rol=='admin' || req.session.rol=='data entry') {
					res.render('login', {
						alert: true,
						alertTitle: "Conexión exitosa",
						alertMessage: "¡LOGIN CORRECTO!",
						alertIcon:'success',
						showConfirmButton: false,
						timer: 1500,
						ruta: 'links'
					}); 
				} else if(req.session.rol=='spectator') {
					res.render('login', {
						alert: true,
						alertTitle: "Conexión exitosa",
						alertMessage: "¡LOGIN CORRECTO!",
						alertIcon:'success',
						showConfirmButton: false,
						timer: 1500,
						ruta: 'spectator'
					}); 
				} else {
					res.render('login', {
						alert: true,
						alertTitle: "Conexión exitosa",
						alertMessage: "¡LOGIN CORRECTO!",
						alertIcon:'success',
						showConfirmButton: false,
						timer: 1500,
						ruta: 'radio'
					}); 
				}     			
			}			
			res.end();
		});
	} else {	
		res.send('Please enter user and Password!');
		res.end();
	}
});
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------

//Función para limpiar la caché luego del logout
app.use(function(req, res, next) {
    if (!req.user)
        res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    next();
});
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------

//Logout
//Destruye la sesión.
app.get('/logout', function (req, res) {
	req.session.destroy(() => {
	  res.redirect('/') // siempre se ejecutará después de que se destruya la sesión
	})
});
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------

//APP CUSTOM
// Leemos todos los registros de la tabla
app.get('/api/:mesa', (req, res) => {
    let mesaGet = req.params.mesa
    connection.query(`SELECT * from ${mesaGet}`, (err, rows) => {
        if(err){
            throw err;
        }else{
            res.send(rows);
        }
    });
});
//----------------------------------------------------------
//----------------------------------------------------------

// Leemos un solo registro de la tabla
app.get('/api/:mesa/:id', (req, res) => {
    let mesaGet = req.params.mesa
    connection.query(`SELECT * from ${mesaGet} where id = ?`, [req.params.id], (err, row) => {
        if(err){
            throw err;
        }else{
            res.send(row);
        }
    });
});
//------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------

// Leer estado de las mesas
app.get('/api/mesas', (req, res) => {
    connection.query(`SELECT * from mesas`, (err, rows) => {
		if(err){
			throw err;
        }else{
			res.send(rows);
        }
    });
});
//------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------

// Enviar/editar votos
app.put("/api/mesas/:id", (req, res) => {
    let id = req.params.id;
	let votosFDT = req.body.votosfdt;
	let votosJXC = req.body.votosjuntos;
	let votosAL = req.body.votosalternativa;
	let votosBlanco = req.body.votosblanco;
	let votosNulo = req.body.votosnulo;
    let estado = 2;
    let sql = `UPDATE mesas SET estado = ?, votosfdt = ?, votosjuntos = ?, votosalternativa = ?, votosblanco = ?, votosnulo = ? WHERE id = ?`;
    connection.query(sql, [estado, votosFDT, votosJXC, votosAL, votosBlanco, votosNulo, id], (err, results) => {
        if(err){
            throw err;
        }else{
            res.send(results);
        }
    });
});
//---------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------

// Editar el estado de las mesas
app.put("/api/mesas/cerrar/:id", (req, res) => {
    let id = req.params.id;
    let estado = 1;
    let sql = `UPDATE mesas SET estado = ? WHERE id = ?`;
    connection.query(sql, [estado, id], (err, results) => {
        if(err){
            throw err;
        }else{
            res.send(results);
        }
    });
});
//---------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------

// Ingresar un nuevo registro en la tabla
app.post("/api/:mesa", (req, res) => {
    let mesaPost = req.params.mesa
    let data = {nombre:req.body.nombre, apellido:req.body.apellido, dni:req.body.dni, mesa:req.body.mesa, votacion:req.body.votacion};
    let sql = `INSERT INTO ${mesaPost} SET ?`;
    connection.query(sql, data, (err, results) => {
        if(err){
            throw err;
        }else{
            Object.assign(data, {id: results.insertId})
            res.send(data)
        }
    });
});
//-------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------

// Editar un registro en una mesa de la tabla
app.put("/api/:mesa/:id", (req, res) => {
    let mesaPut = req.params.mesa
    let id = req.params.id;
    let nombre = req.body.nombre;
    let apellido = req.body.apellido;
    let dni = req.body.dni;
    let mesa = req.body.mesa;
    let votacion = req.body.votacion;
    let sql = `UPDATE ${mesaPut} SET nombre = ?, apellido = ?, dni = ?, mesa = ?, votacion = ? WHERE id = ?`;
    connection.query(sql, [nombre, apellido, dni, mesa, votacion, id], (err, results) => {
        if(err){
            throw err;
        }else{
            res.send(results);
        }
    });
});
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------

// Eliminar un registro en la mesa de la tabla
app.delete("/api/:mesa/:id", (req, res) => {
    let mesaDelete = req.params.mesa
    connection.query(`DELETE FROM ${mesaDelete} WHERE id = ?`, [req.params.id], (err, rows) => {
        if(err){
            throw err;
        }else{
            res.send(rows);
        }
    });
});
//---------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------



const appPort = 80
//Inicializamos la app
app.listen(appPort, (req, res)=>{
    console.log(`SERVER RUNNING IN PORT ${appPort}`);
});
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------