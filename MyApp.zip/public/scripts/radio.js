function formatNumber(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

url=`http://18.191.60.88/api/mesas`

let fdt= 0
let jxc = 0
let al = 0
let fdtp = 0
let jxcp = 0
let alp = 0
let totalVotos = fdt+jxc+al

//Local Chart
//setup block
let data = {
    labels: [`${formatNumber(fdt)} Frente de Todos ${fdtp.toFixed(2).replace('.', ',')}%`, `${formatNumber(jxc)} Juntos por el Cambio ${jxcp.toFixed(2).replace('.', ',')}%`, `${formatNumber(al)} Alternativa Legítima ${alp.toFixed(2).replace('.', ',')}%`],
        datasets: [{
            label: '# of Votes',
            data: [fdt, jxc, al],
            backgroundColor: [
                'rgba(28, 157, 217, 0.2)',
                'rgba(242, 232, 46, 0.2)',
                'rgba(130, 34, 181, 0.2)'
            ],
            borderColor: [
                'rgba(28, 157, 217, 1)',
                'rgba(242, 232, 46, 1)',
                'rgba(130, 34, 181, 1)'
            ],
            borderWidth: 1
        }]
};

//config block
let chartConfig = {
    type: 'pie',
    data,
    options: {
        "color": "#fff",
    }
}

//init block (render)
let localChart = new Chart(
    document.getElementById('localChart'),
    chartConfig
);

const cargarData = async () => {
    try {
        const res = await fetch(url);
        dataCargada = await res.json();

        const iconMesa1 = document.getElementById('iconMesa1')
        const iconMesa2 = document.getElementById('iconMesa2')
        const iconMesa3 = document.getElementById('iconMesa3')
        const iconMesa4 = document.getElementById('iconMesa4')
        const iconMesa5 = document.getElementById('iconMesa5')
        const iconMesa6 = document.getElementById('iconMesa6')
        const iconMesa7 = document.getElementById('iconMesa7')
        const iconMesa8 = document.getElementById('iconMesa8')
        const iconMesa9 = document.getElementById('iconMesa9')
        const iconMesa10 = document.getElementById('iconMesa10')
        const iconMesa11 = document.getElementById('iconMesa11')
        const iconMesa12 = document.getElementById('iconMesa12')
        const iconMesa13 = document.getElementById('iconMesa13')

        const estadoMesa1 = document.getElementById('estadoMesa1')
        const estadoMesa2 = document.getElementById('estadoMesa2')
        const estadoMesa3 = document.getElementById('estadoMesa3')
        const estadoMesa4 = document.getElementById('estadoMesa4')
        const estadoMesa5 = document.getElementById('estadoMesa5')
        const estadoMesa6 = document.getElementById('estadoMesa6')
        const estadoMesa7 = document.getElementById('estadoMesa7')
        const estadoMesa8 = document.getElementById('estadoMesa8')
        const estadoMesa9 = document.getElementById('estadoMesa9')
        const estadoMesa10 = document.getElementById('estadoMesa10')
        const estadoMesa11 = document.getElementById('estadoMesa11')
        const estadoMesa12 = document.getElementById('estadoMesa12')
        const estadoMesa13 = document.getElementById('estadoMesa13')

        if(dataCargada[0].estado==1){iconMesa1.src = 'resources/img/drafts.png'; estadoMesa1.innerHTML = 'Contando los votos'}
        if(dataCargada[0].estado==2){iconMesa1.src = 'resources/img/finish.png'; estadoMesa1.innerHTML = 'Datos enviados'}
        if(dataCargada[1].estado==1){iconMesa2.src = 'resources/img/drafts.png'; estadoMesa2.innerHTML = 'Contando los votos'}
        if(dataCargada[1].estado==2){iconMesa2.src = 'resources/img/finish.png'; estadoMesa2.innerHTML = 'Datos enviados'}
        if(dataCargada[2].estado==1){iconMesa3.src = 'resources/img/drafts.png'; estadoMesa3.innerHTML = 'Contando los votos'}
        if(dataCargada[2].estado==2){iconMesa3.src = 'resources/img/finish.png'; estadoMesa3.innerHTML = 'Datos enviados'}
        if(dataCargada[3].estado==1){iconMesa4.src = 'resources/img/drafts.png'; estadoMesa4.innerHTML = 'Contando los votos'}
        if(dataCargada[3].estado==2){iconMesa4.src = 'resources/img/finish.png'; estadoMesa4.innerHTML = 'Datos enviados'}
        if(dataCargada[4].estado==1){iconMesa5.src = 'resources/img/drafts.png'; estadoMesa5.innerHTML = 'Contando los votos'}
        if(dataCargada[4].estado==2){iconMesa5.src = 'resources/img/finish.png'; estadoMesa5.innerHTML = 'Datos enviados'}
        if(dataCargada[5].estado==1){iconMesa6.src = 'resources/img/drafts.png'; estadoMesa6.innerHTML = 'Contando los votos'}
        if(dataCargada[5].estado==2){iconMesa6.src = 'resources/img/finish.png'; estadoMesa6.innerHTML = 'Datos enviados'}
        if(dataCargada[6].estado==1){iconMesa7.src = 'resources/img/drafts.png'; estadoMesa7.innerHTML = 'Contando los votos'}
        if(dataCargada[6].estado==2){iconMesa7.src = 'resources/img/finish.png'; estadoMesa7.innerHTML = 'Datos enviados'}
        if(dataCargada[7].estado==1){iconMesa8.src = 'resources/img/drafts.png'; estadoMesa8.innerHTML = 'Contando los votos'}
        if(dataCargada[7].estado==2){iconMesa8.src = 'resources/img/finish.png'; estadoMesa8.innerHTML = 'Datos enviados'}
        if(dataCargada[8].estado==1){iconMesa9.src = 'resources/img/drafts.png'; estadoMesa9.innerHTML = 'Contando los votos'}
        if(dataCargada[8].estado==2){iconMesa9.src = 'resources/img/finish.png'; estadoMesa9.innerHTML = 'Datos enviados'}
        if(dataCargada[9].estado==1){iconMesa10.src = 'resources/img/drafts.png'; estadoMesa10.innerHTML = 'Contando los votos'}
        if(dataCargada[9].estado==2){iconMesa10.src = 'resources/img/finish.png'; estadoMesa10.innerHTML = 'Datos enviados'}
        if(dataCargada[10].estado==1){iconMesa11.src = 'resources/img/drafts.png'; estadoMesa11.innerHTML = 'Contando los votos'}
        if(dataCargada[10].estado==2){iconMesa11.src = 'resources/img/finish.png'; estadoMesa11.innerHTML = 'Datos enviados'}
        if(dataCargada[11].estado==1){iconMesa12.src = 'resources/img/drafts.png'; estadoMesa12.innerHTML = 'Contando los votos'}
        if(dataCargada[11].estado==2){iconMesa12.src = 'resources/img/finish.png'; estadoMesa12.innerHTML = 'Datos enviados'}
        if(dataCargada[12].estado==1){iconMesa13.src = 'resources/img/drafts.png'; estadoMesa13.innerHTML = 'Contando los votos'}
        if(dataCargada[12].estado==2){iconMesa13.src = 'resources/img/finish.png'; estadoMesa13.innerHTML = 'Datos enviados'}


        let fdtMesa1 = document.getElementById('votosfdt1')
        let fdtMesa2 = document.getElementById('votosfdt2')
        let fdtMesa3 = document.getElementById('votosfdt3')
        let fdtMesa4 = document.getElementById('votosfdt4')
        let fdtMesa5 = document.getElementById('votosfdt5')
        let fdtMesa6 = document.getElementById('votosfdt6')
        let fdtMesa7 = document.getElementById('votosfdt7')
        let fdtMesa8 = document.getElementById('votosfdt8')
        let fdtMesa9 = document.getElementById('votosfdt9')
        let fdtMesa10 = document.getElementById('votosfdt10')
        let fdtMesa11 = document.getElementById('votosfdt11')
        let fdtMesa12 = document.getElementById('votosfdt12')
        let fdtMesa13 = document.getElementById('votosfdt13')
        let juntosMesa1 = document.getElementById('votosjuntos1')
        let juntosMesa2 = document.getElementById('votosjuntos2')
        let juntosMesa3 = document.getElementById('votosjuntos3')
        let juntosMesa4 = document.getElementById('votosjuntos4')
        let juntosMesa5 = document.getElementById('votosjuntos5')
        let juntosMesa6 = document.getElementById('votosjuntos6')
        let juntosMesa7 = document.getElementById('votosjuntos7')
        let juntosMesa8 = document.getElementById('votosjuntos8')
        let juntosMesa9 = document.getElementById('votosjuntos9')
        let juntosMesa10 = document.getElementById('votosjuntos10')
        let juntosMesa11 = document.getElementById('votosjuntos11')
        let juntosMesa12 = document.getElementById('votosjuntos12')
        let juntosMesa13 = document.getElementById('votosjuntos13')
        let alternativaMesa1 = document.getElementById('votosalternativa1')
        let alternativaMesa2 = document.getElementById('votosalternativa2')
        let alternativaMesa3 = document.getElementById('votosalternativa3')
        let alternativaMesa4 = document.getElementById('votosalternativa4')
        let alternativaMesa5 = document.getElementById('votosalternativa5')
        let alternativaMesa6 = document.getElementById('votosalternativa6')
        let alternativaMesa7 = document.getElementById('votosalternativa7')
        let alternativaMesa8 = document.getElementById('votosalternativa8')
        let alternativaMesa9 = document.getElementById('votosalternativa9')
        let alternativaMesa10 = document.getElementById('votosalternativa10')
        let alternativaMesa11 = document.getElementById('votosalternativa11')
        let alternativaMesa12 = document.getElementById('votosalternativa12')
        let alternativaMesa13 = document.getElementById('votosalternativa13')
        let blancoMesa1 = document.getElementById('votosblanco1')
        let blancoMesa2 = document.getElementById('votosblanco2')
        let blancoMesa3 = document.getElementById('votosblanco3')
        let blancoMesa4 = document.getElementById('votosblanco4')
        let blancoMesa5 = document.getElementById('votosblanco5')
        let blancoMesa6 = document.getElementById('votosblanco6')
        let blancoMesa7 = document.getElementById('votosblanco7')
        let blancoMesa8 = document.getElementById('votosblanco8')
        let blancoMesa9 = document.getElementById('votosblanco9')
        let blancoMesa10 = document.getElementById('votosblanco10')
        let blancoMesa11 = document.getElementById('votosblanco11')
        let blancoMesa12 = document.getElementById('votosblanco12')
        let blancoMesa13 = document.getElementById('votosblanco13')
        let nuloMesa1 = document.getElementById('votosnulo1')
        let nuloMesa2 = document.getElementById('votosnulo2')
        let nuloMesa3 = document.getElementById('votosnulo3')
        let nuloMesa4 = document.getElementById('votosnulo4')
        let nuloMesa5 = document.getElementById('votosnulo5')
        let nuloMesa6 = document.getElementById('votosnulo6')
        let nuloMesa7 = document.getElementById('votosnulo7')
        let nuloMesa8 = document.getElementById('votosnulo8')
        let nuloMesa9 = document.getElementById('votosnulo9')
        let nuloMesa10 = document.getElementById('votosnulo10')
        let nuloMesa11 = document.getElementById('votosnulo11')
        let nuloMesa12 = document.getElementById('votosnulo12')
        let nuloMesa13 = document.getElementById('votosnulo13')

        let one = dataCargada[0]
        let two = dataCargada[1]
        let three = dataCargada[2]
        let four = dataCargada[3]
        let five = dataCargada[4]
        let six = dataCargada[5]
        let seven = dataCargada[6]
        let eight = dataCargada[7]
        let nine = dataCargada[8]
        let ten = dataCargada[9]
        let eleven = dataCargada[10]
        let twelve = dataCargada[11]
        let thirteen = dataCargada[12]

        fdtMesa1.innerHTML = `FDT ${one.votosfdt} (${(one.votosfdt*100/(one.votosfdt+one.votosjuntos+one.votosalternativa+one.votosblanco+one.votosnulo)).toFixed(2)}%)`
        fdtMesa2.innerHTML = `FDT ${two.votosfdt} (${(two.votosfdt*100/(two.votosfdt+two.votosjuntos+two.votosalternativa+two.votosblanco+two.votosnulo)).toFixed(2)}%)`
        fdtMesa3.innerHTML = `FDT ${three.votosfdt} (${(three.votosfdt*100/(three.votosfdt+three.votosjuntos+three.votosalternativa+three.votosblanco+three.votosnulo)).toFixed(2)}%)`
        fdtMesa4.innerHTML = `FDT ${four.votosfdt} (${(four.votosfdt*100/(four.votosfdt+four.votosjuntos+four.votosalternativa+four.votosblanco+four.votosnulo)).toFixed(2)}%)`
        fdtMesa5.innerHTML = `FDT ${five.votosfdt} (${(five.votosfdt*100/(five.votosfdt+five.votosjuntos+five.votosalternativa+five.votosblanco+five.votosnulo)).toFixed(2)}%)`
        fdtMesa6.innerHTML = `FDT ${six.votosfdt} (${(six.votosfdt*100/(six.votosfdt+six.votosjuntos+six.votosalternativa+six.votosblanco+six.votosnulo)).toFixed(2)}%)`
        fdtMesa7.innerHTML = `FDT ${seven.votosfdt} (${(seven.votosfdt*100/(seven.votosfdt+seven.votosjuntos+seven.votosalternativa+seven.votosblanco+seven.votosnulo)).toFixed(2)}%)`
        fdtMesa8.innerHTML = `FDT ${eight.votosfdt} (${(eight.votosfdt*100/(eight.votosfdt+eight.votosjuntos+eight.votosalternativa+eight.votosblanco+eight.votosnulo)).toFixed(2)}%)`
        fdtMesa9.innerHTML = `FDT ${nine.votosfdt} (${(nine.votosfdt*100/(nine.votosfdt+nine.votosjuntos+nine.votosalternativa+nine.votosblanco+nine.votosnulo)).toFixed(2)}%)`
        fdtMesa10.innerHTML = `FDT ${ten.votosfdt} (${(ten.votosfdt*100/(ten.votosfdt+ten.votosjuntos+ten.votosalternativa+ten.votosblanco+ten.votosnulo)).toFixed(2)}%)`
        fdtMesa11.innerHTML = `FDT ${eleven.votosfdt} (${(eleven.votosfdt*100/(eleven.votosfdt+eleven.votosjuntos+eleven.votosalternativa+eleven.votosblanco+eleven.votosnulo)).toFixed(2)}%)`
        fdtMesa12.innerHTML = `FDT ${twelve.votosfdt} (${(twelve.votosfdt*100/(twelve.votosfdt+twelve.votosjuntos+twelve.votosalternativa+twelve.votosblanco+twelve.votosnulo)).toFixed(2)}%)`
        fdtMesa13.innerHTML = `FDT ${thirteen.votosfdt} (${(thirteen.votosfdt*100/(thirteen.votosfdt+thirteen.votosjuntos+thirteen.votosalternativa+thirteen.votosblanco+thirteen.votosnulo)).toFixed(2)}%)`

        juntosMesa1.innerHTML = `Juntos ${one.votosjuntos} (${(one.votosjuntos*100/(one.votosfdt+one.votosjuntos+one.votosalternativa+one.votosblanco+one.votosnulo)).toFixed(2)}%)`
        juntosMesa2.innerHTML = `Juntos ${two.votosjuntos} (${(two.votosjuntos*100/(two.votosfdt+two.votosjuntos+two.votosalternativa+two.votosblanco+two.votosnulo)).toFixed(2)}%)`
        juntosMesa3.innerHTML = `Juntos ${three.votosjuntos} (${(three.votosjuntos*100/(three.votosfdt+three.votosjuntos+three.votosalternativa+three.votosblanco+three.votosnulo)).toFixed(2)}%)`
        juntosMesa4.innerHTML = `Juntos ${four.votosjuntos} (${(four.votosjuntos*100/(four.votosfdt+four.votosjuntos+four.votosalternativa+four.votosblanco+four.votosnulo)).toFixed(2)}%)`
        juntosMesa5.innerHTML = `Juntos ${five.votosjuntos} (${(five.votosjuntos*100/(five.votosfdt+five.votosjuntos+five.votosalternativa+five.votosblanco+five.votosnulo)).toFixed(2)}%)`
        juntosMesa6.innerHTML = `Juntos ${six.votosjuntos} (${(six.votosjuntos*100/(six.votosfdt+six.votosjuntos+six.votosalternativa+six.votosblanco+six.votosnulo)).toFixed(2)}%)`
        juntosMesa7.innerHTML = `Juntos ${seven.votosjuntos} (${(seven.votosjuntos*100/(seven.votosfdt+seven.votosjuntos+seven.votosalternativa+seven.votosblanco+seven.votosnulo)).toFixed(2)}%)`
        juntosMesa8.innerHTML = `Juntos ${eight.votosjuntos} (${(eight.votosjuntos*100/(eight.votosfdt+eight.votosjuntos+eight.votosalternativa+eight.votosblanco+eight.votosnulo)).toFixed(2)}%)`
        juntosMesa9.innerHTML = `Juntos ${nine.votosjuntos} (${(nine.votosjuntos*100/(nine.votosfdt+nine.votosjuntos+nine.votosalternativa+nine.votosblanco+nine.votosnulo)).toFixed(2)}%)`
        juntosMesa10.innerHTML = `Juntos ${ten.votosjuntos} (${(ten.votosjuntos*100/(ten.votosfdt+ten.votosjuntos+ten.votosalternativa+ten.votosblanco+ten.votosnulo)).toFixed(2)}%)`
        juntosMesa11.innerHTML = `Juntos ${eleven.votosjuntos} (${(eleven.votosjuntos*100/(eleven.votosfdt+eleven.votosjuntos+eleven.votosalternativa+eleven.votosblanco+eleven.votosnulo)).toFixed(2)}%)`
        juntosMesa12.innerHTML = `Juntos ${twelve.votosjuntos} (${(twelve.votosjuntos*100/(twelve.votosfdt+twelve.votosjuntos+twelve.votosalternativa+twelve.votosblanco+twelve.votosnulo)).toFixed(2)}%)`
        juntosMesa13.innerHTML = `Juntos ${thirteen.votosjuntos} (${(thirteen.votosjuntos*100/(thirteen.votosfdt+thirteen.votosjuntos+thirteen.votosalternativa+thirteen.votosblanco+thirteen.votosnulo)).toFixed(2)}%)`

        alternativaMesa1.innerHTML = `Alt. Leg. ${one.votosalternativa} (${(one.votosalternativa*100/(one.votosfdt+one.votosjuntos+one.votosalternativa+one.votosblanco+one.votosnulo)).toFixed(2)}%)`
        alternativaMesa2.innerHTML = `Alt. Leg. ${two.votosalternativa} (${(two.votosalternativa*100/(two.votosfdt+two.votosjuntos+two.votosalternativa+two.votosblanco+two.votosnulo)).toFixed(2)}%)`
        alternativaMesa3.innerHTML = `Alt. Leg. ${three.votosalternativa} (${(three.votosalternativa*100/(three.votosfdt+three.votosjuntos+three.votosalternativa+three.votosblanco+three.votosnulo)).toFixed(2)}%)`
        alternativaMesa4.innerHTML = `Alt. Leg. ${four.votosalternativa} (${(four.votosalternativa*100/(four.votosfdt+four.votosjuntos+four.votosalternativa+four.votosblanco+four.votosnulo)).toFixed(2)}%)`
        alternativaMesa5.innerHTML = `Alt. Leg. ${five.votosalternativa} (${(five.votosalternativa*100/(five.votosfdt+five.votosjuntos+five.votosalternativa+five.votosblanco+five.votosnulo)).toFixed(2)}%)`
        alternativaMesa6.innerHTML = `Alt. Leg. ${six.votosalternativa} (${(six.votosalternativa*100/(six.votosfdt+six.votosjuntos+six.votosalternativa+six.votosblanco+six.votosnulo)).toFixed(2)}%)`
        alternativaMesa7.innerHTML = `Alt. Leg. ${seven.votosalternativa} (${(seven.votosalternativa*100/(seven.votosfdt+seven.votosjuntos+seven.votosalternativa+seven.votosblanco+seven.votosnulo)).toFixed(2)}%)`
        alternativaMesa8.innerHTML = `Alt. Leg. ${eight.votosalternativa} (${(eight.votosalternativa*100/(eight.votosfdt+eight.votosjuntos+eight.votosalternativa+eight.votosblanco+eight.votosnulo)).toFixed(2)}%)`
        alternativaMesa9.innerHTML = `Alt. Leg. ${nine.votosalternativa} (${(nine.votosalternativa*100/(nine.votosfdt+nine.votosjuntos+nine.votosalternativa+nine.votosblanco+nine.votosnulo)).toFixed(2)}%)`
        alternativaMesa10.innerHTML = `Alt. Leg. ${ten.votosalternativa} (${(ten.votosalternativa*100/(ten.votosfdt+ten.votosjuntos+ten.votosalternativa+ten.votosblanco+ten.votosnulo)).toFixed(2)}%)`
        alternativaMesa11.innerHTML = `Alt. Leg. ${eleven.votosalternativa} (${(eleven.votosalternativa*100/(eleven.votosfdt+eleven.votosjuntos+eleven.votosalternativa+eleven.votosblanco+eleven.votosnulo)).toFixed(2)}%)`
        alternativaMesa12.innerHTML = `Alt. Leg. ${twelve.votosalternativa} (${(twelve.votosalternativa*100/(twelve.votosfdt+twelve.votosjuntos+twelve.votosalternativa+twelve.votosblanco+twelve.votosnulo)).toFixed(2)}%)`
        alternativaMesa13.innerHTML = `Alt. Leg. ${thirteen.votosalternativa} (${(thirteen.votosalternativa*100/(thirteen.votosfdt+thirteen.votosjuntos+thirteen.votosalternativa+thirteen.votosblanco+thirteen.votosnulo)).toFixed(2)}%)`

        blancoMesa1.innerHTML = `Blancos ${one.votosblanco} (${(one.votosblanco*100/(one.votosfdt+one.votosjuntos+one.votosalternativa+one.votosblanco+one.votosnulo)).toFixed(2)}%)`
        blancoMesa2.innerHTML = `Blancos ${two.votosblanco} (${(two.votosblanco*100/(two.votosfdt+two.votosjuntos+two.votosalternativa+two.votosblanco+two.votosnulo)).toFixed(2)}%)`
        blancoMesa3.innerHTML = `Blancos ${three.votosblanco} (${(three.votosblanco*100/(three.votosfdt+three.votosjuntos+three.votosalternativa+three.votosblanco+three.votosnulo)).toFixed(2)}%)`
        blancoMesa4.innerHTML = `Blancos ${four.votosblanco} (${(four.votosblanco*100/(four.votosfdt+four.votosjuntos+four.votosalternativa+four.votosblanco+four.votosnulo)).toFixed(2)}%)`
        blancoMesa5.innerHTML = `Blancos ${five.votosblanco} (${(five.votosblanco*100/(five.votosfdt+five.votosjuntos+five.votosalternativa+five.votosblanco+five.votosnulo)).toFixed(2)}%)`
        blancoMesa6.innerHTML = `Blancos ${six.votosblanco} (${(six.votosblanco*100/(six.votosfdt+six.votosjuntos+six.votosalternativa+six.votosblanco+six.votosnulo)).toFixed(2)}%)`
        blancoMesa7.innerHTML = `Blancos ${seven.votosblanco} (${(seven.votosblanco*100/(seven.votosfdt+seven.votosjuntos+seven.votosalternativa+seven.votosblanco+seven.votosnulo)).toFixed(2)}%)`
        blancoMesa8.innerHTML = `Blancos ${eight.votosblanco} (${(eight.votosblanco*100/(eight.votosfdt+eight.votosjuntos+eight.votosalternativa+eight.votosblanco+eight.votosnulo)).toFixed(2)}%)`
        blancoMesa9.innerHTML = `Blancos ${nine.votosblanco} (${(nine.votosblanco*100/(nine.votosfdt+nine.votosjuntos+nine.votosalternativa+nine.votosblanco+nine.votosnulo)).toFixed(2)}%)`
        blancoMesa10.innerHTML = `Blancos ${ten.votosblanco} (${(ten.votosblanco*100/(ten.votosfdt+ten.votosjuntos+ten.votosalternativa+ten.votosblanco+ten.votosnulo)).toFixed(2)}%)`
        blancoMesa11.innerHTML = `Blancos ${eleven.votosblanco} (${(eleven.votosblanco*100/(eleven.votosfdt+eleven.votosjuntos+eleven.votosalternativa+eleven.votosblanco+eleven.votosnulo)).toFixed(2)}%)`
        blancoMesa12.innerHTML = `Blancos ${twelve.votosblanco} (${(twelve.votosblanco*100/(twelve.votosfdt+twelve.votosjuntos+twelve.votosalternativa+twelve.votosblanco+twelve.votosnulo)).toFixed(2)}%)`
        blancoMesa13.innerHTML = `Blancos ${thirteen.votosblanco} (${(thirteen.votosblanco*100/(thirteen.votosfdt+thirteen.votosjuntos+thirteen.votosalternativa+thirteen.votosblanco+thirteen.votosnulo)).toFixed(2)}%)`

        nuloMesa1.innerHTML = `Nulos ${one.votosnulo} (${(one.votosnulo*100/(one.votosfdt+one.votosjuntos+one.votosalternativa+one.votosblanco+one.votosnulo)).toFixed(2)}%)`
        nuloMesa2.innerHTML = `Nulos ${two.votosnulo} (${(two.votosnulo*100/(two.votosfdt+two.votosjuntos+two.votosalternativa+two.votosblanco+two.votosnulo)).toFixed(2)}%)`
        nuloMesa3.innerHTML = `Nulos ${three.votosnulo} (${(three.votosnulo*100/(three.votosfdt+three.votosjuntos+three.votosalternativa+three.votosblanco+three.votosnulo)).toFixed(2)}%)`
        nuloMesa4.innerHTML = `Nulos ${four.votosnulo} (${(four.votosnulo*100/(four.votosfdt+four.votosjuntos+four.votosalternativa+four.votosblanco+four.votosnulo)).toFixed(2)}%)`
        nuloMesa5.innerHTML = `Nulos ${five.votosnulo} (${(five.votosnulo*100/(five.votosfdt+five.votosjuntos+five.votosalternativa+five.votosblanco+five.votosnulo)).toFixed(2)}%)`
        nuloMesa6.innerHTML = `Nulos ${six.votosnulo} (${(six.votosnulo*100/(six.votosfdt+six.votosjuntos+six.votosalternativa+six.votosblanco+six.votosnulo)).toFixed(2)}%)`
        nuloMesa7.innerHTML = `Nulos ${seven.votosnulo} (${(seven.votosnulo*100/(seven.votosfdt+seven.votosjuntos+seven.votosalternativa+seven.votosblanco+seven.votosnulo)).toFixed(2)}%)`
        nuloMesa8.innerHTML = `Nulos ${eight.votosnulo} (${(eight.votosnulo*100/(eight.votosfdt+eight.votosjuntos+eight.votosalternativa+eight.votosblanco+eight.votosnulo)).toFixed(2)}%)`
        nuloMesa9.innerHTML = `Nulos ${nine.votosnulo} (${(nine.votosnulo*100/(nine.votosfdt+nine.votosjuntos+nine.votosalternativa+nine.votosblanco+nine.votosnulo)).toFixed(2)}%)`
        nuloMesa10.innerHTML = `Nulos ${ten.votosnulo} (${(ten.votosnulo*100/(ten.votosfdt+ten.votosjuntos+ten.votosalternativa+ten.votosblanco+ten.votosnulo)).toFixed(2)}%)`
        nuloMesa11.innerHTML = `Nulos ${eleven.votosnulo} (${(eleven.votosnulo*100/(eleven.votosfdt+eleven.votosjuntos+eleven.votosalternativa+eleven.votosblanco+eleven.votosnulo)).toFixed(2)}%)`
        nuloMesa12.innerHTML = `Nulos ${twelve.votosnulo} (${(twelve.votosnulo*100/(twelve.votosfdt+twelve.votosjuntos+twelve.votosalternativa+twelve.votosblanco+twelve.votosnulo)).toFixed(2)}%)`
        nuloMesa13.innerHTML = `Nulos ${thirteen.votosnulo} (${(thirteen.votosnulo*100/(thirteen.votosfdt+thirteen.votosjuntos+thirteen.votosalternativa+thirteen.votosblanco+thirteen.votosnulo)).toFixed(2)}%)`

        fdt= 0
        jxc = 0
        al = 0
        fdtp = 0
        jxcp = 0
        alp = 0
        totalVotos = fdt+jxc+al
        for (let i=0; i<13; i++) {
            fdt+=dataCargada[i].votosfdt
            jxc+=dataCargada[i].votosjuntos
            al+=dataCargada[i].votosalternativa
        }

        totalVotos = fdt+jxc+al
        fdtp = fdt*100/totalVotos
        jxcp = jxc*100/totalVotos
        alp = al*100/totalVotos

        
        
        data = {
            labels: [`${formatNumber(fdt)} Frente de Todos ${fdtp.toFixed(2).replace('.', ',')}%`, `${formatNumber(jxc)} Juntos por el Cambio ${jxcp.toFixed(2).replace('.', ',')}%`, `${formatNumber(al)} Alternativa Legítima ${alp.toFixed(2).replace('.', ',')}%`],
                datasets: [{
                    label: '# of Votes',
                    data: [fdt, jxc, al],
                    backgroundColor: [
                        'rgba(28, 157, 217, 0.2)',
                        'rgba(242, 232, 46, 0.2)',
                        'rgba(130, 34, 181, 0.2)'
                    ],
                    borderColor: [
                        'rgba(28, 157, 217, 1)',
                        'rgba(242, 232, 46, 1)',
                        'rgba(130, 34, 181, 1)'
                    ],
                    borderWidth: 1
                }]
        };

        chartConfig = {
            type: 'pie',
            data,
            options: {
                "color": "#fff",
            }
        }

        

        const totalRegistros = document.getElementById('totalRegistros')
        const totalVotantes = document.getElementById('totalVotantes')
        const individualMesa1P = document.getElementById('individualMesa1P')
        const individualMesa2P = document.getElementById('individualMesa2P')
        const individualMesa3P = document.getElementById('individualMesa3P')
        const individualMesa4P = document.getElementById('individualMesa4P')
        const individualMesa5P = document.getElementById('individualMesa5P')
        const individualMesa6P = document.getElementById('individualMesa6P')
        const individualMesa7P = document.getElementById('individualMesa7P')
        const individualMesa8P = document.getElementById('individualMesa8P')
        const individualMesa9P = document.getElementById('individualMesa9P')
        const individualMesa10P = document.getElementById('individualMesa10P')
        const individualMesa11P = document.getElementById('individualMesa11P')
        const individualMesa12P = document.getElementById('individualMesa12P')
        const individualMesa13P = document.getElementById('individualMesa13P')
        let numeroTotalRegistros = 0
        let numeroTotalVotantes = 0
        let numeroTotalVotantesP = 0
        for (mesaNumero=1; mesaNumero < 14; mesaNumero++) {
            url = `http://18.191.60.88/api/mesa${mesaNumero}/`
            const res2 = await fetch(url);
            data = await res2.json();
            dataLenght = Object.keys(data).length
            let numeroVotantesIndividual = 0
            let numeroVotantesIndividualP = 0
            data.map((registro) => {
                if(registro.votacion==1) {
                    numeroTotalVotantes++
                    numeroTotalRegistros++
                    numeroVotantesIndividual++
                }else {
                    numeroTotalRegistros++
                }
            })
        numeroVotantesIndividualP = numeroVotantesIndividual*100/dataLenght
        if(mesaNumero==1){individualMesa1P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==2){individualMesa2P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==3){individualMesa3P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==4){individualMesa4P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==5){individualMesa5P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==6){individualMesa6P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==7){individualMesa7P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==8){individualMesa8P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==9){individualMesa9P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==10){individualMesa10P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==11){individualMesa11P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==12){individualMesa12P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==13){individualMesa13P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}

        
        }
        numeroTotalVotantesP = numeroTotalVotantes*100/numeroTotalRegistros
        totalRegistros.innerHTML = `Total de registros: ${numeroTotalRegistros}`
        totalVotantes.innerHTML = `Total de votantes: ${numeroTotalVotantes} (${numeroTotalVotantesP.toFixed(2)}%)`
        
        localChart.data.datasets[0].data = [fdt, jxc, al]
        localChart.data.labels = [`${formatNumber(fdt)} Frente de Todos ${fdtp.toFixed(2).replace('.', ',')}%`, `${formatNumber(jxc)} Juntos por el Cambio ${jxcp.toFixed(2).replace('.', ',')}%`, `${formatNumber(al)} Alternativa Legítima ${alp.toFixed(2).replace('.', ',')}%`]
        localChart.update()
    } catch (err) {
        console.error(err);
    }
};


cargarData()

//--------------------------------------------------------------------
//--------------------------------------------------------------------
//--------------------------------------------------------------------