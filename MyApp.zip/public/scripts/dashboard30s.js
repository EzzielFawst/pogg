function formatNumber(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

url=`http://18.191.60.88/api/mesas`

let fdt= 0
let jxc = 0
let al = 0
let fdtp = 0
let jxcp = 0
let alp = 0
let totalVotos = fdt+jxc+al

//Local Chart
//setup block
let data = {
    labels: [`${formatNumber(fdt)} Frente de Todos ${fdtp.toFixed(2).replace('.', ',')}%`, `${formatNumber(jxc)} Juntos por el Cambio ${jxcp.toFixed(2).replace('.', ',')}%`, `${formatNumber(al)} Alternativa Legítima ${alp.toFixed(2).replace('.', ',')}%`],
        datasets: [{
            label: '# of Votes',
            data: [fdt, jxc, al],
            backgroundColor: [
                'rgba(28, 157, 217, 0.2)',
                'rgba(242, 232, 46, 0.2)',
                'rgba(130, 34, 181, 0.2)'
            ],
            borderColor: [
                'rgba(28, 157, 217, 1)',
                'rgba(242, 232, 46, 1)',
                'rgba(130, 34, 181, 1)'
            ],
            borderWidth: 1
        }]
};

//config block
let chartConfig = {
    type: 'pie',
    data,
    options: {
        "color": "#fff",
    }
}

//init block (render)
let localChart = new Chart(
    document.getElementById('localChart'),
    chartConfig
);

const cargarData = async () => {
    try {
        const res = await fetch(url);
        dataCargada = await res.json();

        const iconMesa1 = document.getElementById('iconMesa1')
        const iconMesa2 = document.getElementById('iconMesa2')
        const iconMesa3 = document.getElementById('iconMesa3')
        const iconMesa4 = document.getElementById('iconMesa4')
        const iconMesa5 = document.getElementById('iconMesa5')
        const iconMesa6 = document.getElementById('iconMesa6')
        const iconMesa7 = document.getElementById('iconMesa7')
        const iconMesa8 = document.getElementById('iconMesa8')
        const iconMesa9 = document.getElementById('iconMesa9')
        const iconMesa10 = document.getElementById('iconMesa10')
        const iconMesa11 = document.getElementById('iconMesa11')
        const iconMesa12 = document.getElementById('iconMesa12')
        const iconMesa13 = document.getElementById('iconMesa13')
        const estadoMesa1 = document.getElementById('estadoMesa1')
        const estadoMesa2 = document.getElementById('estadoMesa2')
        const estadoMesa3 = document.getElementById('estadoMesa3')
        const estadoMesa4 = document.getElementById('estadoMesa4')
        const estadoMesa5 = document.getElementById('estadoMesa5')
        const estadoMesa6 = document.getElementById('estadoMesa6')
        const estadoMesa7 = document.getElementById('estadoMesa7')
        const estadoMesa8 = document.getElementById('estadoMesa8')
        const estadoMesa9 = document.getElementById('estadoMesa9')
        const estadoMesa10 = document.getElementById('estadoMesa10')
        const estadoMesa11 = document.getElementById('estadoMesa11')
        const estadoMesa12 = document.getElementById('estadoMesa12')
        const estadoMesa13 = document.getElementById('estadoMesa13')

        if(dataCargada[0].estado==1){iconMesa1.src = 'resources/img/drafts.png'; estadoMesa1.innerHTML = 'Contando los votos'}
        if(dataCargada[0].estado==2){iconMesa1.src = 'resources/img/finish.png'; estadoMesa1.innerHTML = 'Datos enviados'}
        if(dataCargada[1].estado==1){iconMesa2.src = 'resources/img/drafts.png'; estadoMesa2.innerHTML = 'Contando los votos'}
        if(dataCargada[1].estado==2){iconMesa2.src = 'resources/img/finish.png'; estadoMesa2.innerHTML = 'Datos enviados'}
        if(dataCargada[2].estado==1){iconMesa3.src = 'resources/img/drafts.png'; estadoMesa3.innerHTML = 'Contando los votos'}
        if(dataCargada[2].estado==2){iconMesa3.src = 'resources/img/finish.png'; estadoMesa3.innerHTML = 'Datos enviados'}
        if(dataCargada[3].estado==1){iconMesa4.src = 'resources/img/drafts.png'; estadoMesa4.innerHTML = 'Contando los votos'}
        if(dataCargada[3].estado==2){iconMesa4.src = 'resources/img/finish.png'; estadoMesa4.innerHTML = 'Datos enviados'}
        if(dataCargada[4].estado==1){iconMesa5.src = 'resources/img/drafts.png'; estadoMesa5.innerHTML = 'Contando los votos'}
        if(dataCargada[4].estado==2){iconMesa5.src = 'resources/img/finish.png'; estadoMesa5.innerHTML = 'Datos enviados'}
        if(dataCargada[5].estado==1){iconMesa6.src = 'resources/img/drafts.png'; estadoMesa6.innerHTML = 'Contando los votos'}
        if(dataCargada[5].estado==2){iconMesa6.src = 'resources/img/finish.png'; estadoMesa6.innerHTML = 'Datos enviados'}
        if(dataCargada[6].estado==1){iconMesa7.src = 'resources/img/drafts.png'; estadoMesa7.innerHTML = 'Contando los votos'}
        if(dataCargada[6].estado==2){iconMesa7.src = 'resources/img/finish.png'; estadoMesa7.innerHTML = 'Datos enviados'}
        if(dataCargada[7].estado==1){iconMesa8.src = 'resources/img/drafts.png'; estadoMesa8.innerHTML = 'Contando los votos'}
        if(dataCargada[7].estado==2){iconMesa8.src = 'resources/img/finish.png'; estadoMesa8.innerHTML = 'Datos enviados'}
        if(dataCargada[8].estado==1){iconMesa9.src = 'resources/img/drafts.png'; estadoMesa9.innerHTML = 'Contando los votos'}
        if(dataCargada[8].estado==2){iconMesa9.src = 'resources/img/finish.png'; estadoMesa9.innerHTML = 'Datos enviados'}
        if(dataCargada[9].estado==1){iconMesa10.src = 'resources/img/drafts.png'; estadoMesa10.innerHTML = 'Contando los votos'}
        if(dataCargada[9].estado==2){iconMesa10.src = 'resources/img/finish.png'; estadoMesa10.innerHTML = 'Datos enviados'}
        if(dataCargada[10].estado==1){iconMesa11.src = 'resources/img/drafts.png'; estadoMesa11.innerHTML = 'Contando los votos'}
        if(dataCargada[10].estado==2){iconMesa11.src = 'resources/img/finish.png'; estadoMesa11.innerHTML = 'Datos enviados'}
        if(dataCargada[11].estado==1){iconMesa12.src = 'resources/img/drafts.png'; estadoMesa12.innerHTML = 'Contando los votos'}
        if(dataCargada[11].estado==2){iconMesa12.src = 'resources/img/finish.png'; estadoMesa12.innerHTML = 'Datos enviados'}
        if(dataCargada[12].estado==1){iconMesa13.src = 'resources/img/drafts.png'; estadoMesa13.innerHTML = 'Contando los votos'}
        if(dataCargada[12].estado==2){iconMesa13.src = 'resources/img/finish.png'; estadoMesa13.innerHTML = 'Datos enviados'}


        fdt= 0
        jxc = 0
        al = 0
        fdtp = 0
        jxcp = 0
        alp = 0
        totalVotos = fdt+jxc+al
        for (let i=0; i<13; i++) {
            fdt+=dataCargada[i].votosfdt
            jxc+=dataCargada[i].votosjuntos
            al+=dataCargada[i].votosalternativa
        }

        totalVotos = fdt+jxc+al
        fdtp = fdt*100/totalVotos
        jxcp = jxc*100/totalVotos
        alp = al*100/totalVotos

        
        
        data = {
            labels: [`${formatNumber(fdt)} Frente de Todos ${fdtp.toFixed(2).replace('.', ',')}%`, `${formatNumber(jxc)} Juntos por el Cambio ${jxcp.toFixed(2).replace('.', ',')}%`, `${formatNumber(al)} Alternativa Legítima ${alp.toFixed(2).replace('.', ',')}%`],
                datasets: [{
                    label: '# of Votes',
                    data: [fdt, jxc, al],
                    backgroundColor: [
                        'rgba(28, 157, 217, 0.2)',
                        'rgba(242, 232, 46, 0.2)',
                        'rgba(130, 34, 181, 0.2)'
                    ],
                    borderColor: [
                        'rgba(28, 157, 217, 1)',
                        'rgba(242, 232, 46, 1)',
                        'rgba(130, 34, 181, 1)'
                    ],
                    borderWidth: 1
                }]
        };

        chartConfig = {
            type: 'pie',
            data,
            options: {
                "color": "#fff",
            }
        }

        

        const totalRegistros = document.getElementById('totalRegistros')
        const totalVotantes = document.getElementById('totalVotantes')
        const individualMesa1P = document.getElementById('individualMesa1P')
        const individualMesa2P = document.getElementById('individualMesa2P')
        const individualMesa3P = document.getElementById('individualMesa3P')
        const individualMesa4P = document.getElementById('individualMesa4P')
        const individualMesa5P = document.getElementById('individualMesa5P')
        const individualMesa6P = document.getElementById('individualMesa6P')
        const individualMesa7P = document.getElementById('individualMesa7P')
        const individualMesa8P = document.getElementById('individualMesa8P')
        const individualMesa9P = document.getElementById('individualMesa9P')
        const individualMesa10P = document.getElementById('individualMesa10P')
        const individualMesa11P = document.getElementById('individualMesa11P')
        const individualMesa12P = document.getElementById('individualMesa12P')
        const individualMesa13P = document.getElementById('individualMesa13P')
        let numeroTotalRegistros = 0
        let numeroTotalVotantes = 0
        let numeroTotalVotantesP = 0
        for (mesaNumero=1; mesaNumero < 14; mesaNumero++) {
            url = `http://18.191.60.88/api/mesa${mesaNumero}/`
            const res2 = await fetch(url);
            data = await res2.json();
            dataLenght = Object.keys(data).length
            let numeroVotantesIndividual = 0
            let numeroVotantesIndividualP = 0
            data.map((registro) => {
                if(registro.votacion==1) {
                    numeroTotalVotantes++
                    numeroTotalRegistros++
                    numeroVotantesIndividual++
                }else {
                    numeroTotalRegistros++
                }
            })
        numeroVotantesIndividualP = numeroVotantesIndividual*100/dataLenght
        if(mesaNumero==1){individualMesa1P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==2){individualMesa2P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==3){individualMesa3P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==4){individualMesa4P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==5){individualMesa5P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==6){individualMesa6P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==7){individualMesa7P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==8){individualMesa8P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==9){individualMesa9P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==10){individualMesa10P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==11){individualMesa11P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==12){individualMesa12P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}
        if(mesaNumero==13){individualMesa13P.innerHTML = `${numeroVotantesIndividualP.toFixed(2).replace('.', ',')}%`}

        
        }
        numeroTotalVotantesP = numeroTotalVotantes*100/numeroTotalRegistros
        totalRegistros.innerHTML = `Total de registros: ${numeroTotalRegistros}`
        totalVotantes.innerHTML = `Total de votantes: ${numeroTotalVotantes} (${numeroTotalVotantesP.toFixed(2)}%)`
        
        localChart.data.datasets[0].data = [fdt, jxc, al]
        localChart.data.labels = [`${formatNumber(fdt)} Frente de Todos ${fdtp.toFixed(2).replace('.', ',')}%`, `${formatNumber(jxc)} Juntos por el Cambio ${jxcp.toFixed(2).replace('.', ',')}%`, `${formatNumber(al)} Alternativa Legítima ${alp.toFixed(2).replace('.', ',')}%`]
        localChart.update()
    } catch (err) {
        console.error(err);
    }
};




const startLiveUpdate = () => {
    setInterval( () => {
        window.location.reload()
    }, 30000)
}
cargarData()
startLiveUpdate()

//--------------------------------------------------------------------
//--------------------------------------------------------------------
//--------------------------------------------------------------------