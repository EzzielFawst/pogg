//Definición de variables
let mesaNumero = 1
let url = `http://18.191.60.88/api/mesa${mesaNumero}/`
let regList = document.getElementById(`bodyMesa${mesaNumero}`)
let bodiv = document.getElementById(`tablaMesa${mesaNumero}`)
const searchBar = document.getElementById('searchBar');
const btnTodos = document.getElementById('btnTodos');
const btnVotaron = document.getElementById('btnVotaron');
const btnNoVotaron = document.getElementById('btnNoVotaron');
let votantes = [];
let votantesTodos = [];

//Función de búsqueda
searchBar.addEventListener('keyup', (e) => {
    btnTodos.disabled = false
    btnNoVotaron.disabled = false
    btnVotaron.disabled = false
    mesaNumero=1
    const searchString = e.target.value.toLowerCase();
    if(searchString==''){
        btnTodos.disabled = true
    }
    votantesTodos.map((i) => {
        const votantesFiltrados = i.filter((votante) => {
            const votanteNombreCompleto = votante.apellido+' '+votante.nombre+' '+votante.dni
            return (
                votanteNombreCompleto.toLowerCase().includes(searchString)
            );
        });
        regList = document.getElementById(`bodyMesa${mesaNumero}`)
        bodiv = document.getElementById(`tablaMesa${mesaNumero}`)
        if(!votantesFiltrados[0]) {
            bodiv.classList.add("hidden")
        }
        if(votantesFiltrados[0]) {
            bodiv.classList.remove("hidden")
        }
        mostrar(votantesFiltrados, regList);
        mesaNumero++
    })
});


//Función de filtrado (botones)
btnTodos.addEventListener('click', (e) => {
    btnTodos.disabled = true
    btnNoVotaron.disabled = false
    btnVotaron.disabled = false
    searchBar.value=''
    mesaNumero=1
    votantesTodos.map((i) => {
        const votantesFiltrados = i.filter((votante) => {
            return (
                votante.votacion==1 ||
                votante.votacion==0
            );
        });
        regList = document.getElementById(`bodyMesa${mesaNumero}`)
        bodiv = document.getElementById(`tablaMesa${mesaNumero}`)
        if(!votantesFiltrados[0]) {
            bodiv.classList.add("hidden")
        }
        if(votantesFiltrados[0]) {
            bodiv.classList.remove("hidden")
        }
        mostrar(votantesFiltrados, regList);
        mesaNumero++
        })
    }
)

btnVotaron.addEventListener('click', (e) => {
    btnTodos.disabled = false
    btnNoVotaron.disabled = false
    btnVotaron.disabled = true
    searchBar.value=''
    mesaNumero=1
    votantesTodos.map((i) => {
        const votantesFiltrados = i.filter((votante) => {
            return (
                votante.votacion==1
            );
        });
        regList = document.getElementById(`bodyMesa${mesaNumero}`)
        bodiv = document.getElementById(`tablaMesa${mesaNumero}`)
        if(!votantesFiltrados[0]) {
            bodiv.classList.add("hidden")
        }
        if(votantesFiltrados[0]) {
            bodiv.classList.remove("hidden")
        }
        mostrar(votantesFiltrados, regList);
        mesaNumero++
        })
    }
)

btnNoVotaron.addEventListener('click', (e) => {
    btnTodos.disabled = false
    btnNoVotaron.disabled = true
    btnVotaron.disabled = false
    searchBar.value=''
    mesaNumero=1
    votantesTodos.map((i) => {
        const votantesFiltrados = i.filter((votante) => {
            return (
                votante.votacion==0
            );
        });
        regList = document.getElementById(`bodyMesa${mesaNumero}`)
        bodiv = document.getElementById(`tablaMesa${mesaNumero}`)
        if(!votantesFiltrados[0]) {
            bodiv.classList.add("hidden")
        }
        if(votantesFiltrados[0]) {
            bodiv.classList.remove("hidden")
        }
        mostrar(votantesFiltrados, regList);
        mesaNumero++
        })
    }
)

//Función para cargar los votantes
const cargarVotantes = async () => {
    try {
        for (mesaNumero=1; mesaNumero < 15; mesaNumero++) {
            url = `http://18.191.60.88/api/mesa${mesaNumero}/`
            const res = await fetch(url);
            votantes = await res.json();
            regList = document.getElementById(`bodyMesa${mesaNumero}`)
            mostrar(votantes, regList);
            votantesTodos.push(votantes)
        }
    } catch (err) {
        console.error(err);
    }
};

//Función para mostrar los resultados
const mostrar = (registros, regListID) => {
    const htmlString = registros
        .map((registro) => {
            if(registro.votacion==1) {
                return `
                <tr class='selectMe' id='${registro.id}'>
                <td class="text-center centerialize" style="background-color: #75b55e; color: white;">${registro.id}</td>
                <td class="text-center centerialize" style="background-color: #75b55e; color: white;">${registro.apellido}</td>
                <td class="text-center centerialize" style="background-color: #75b55e; color: white;">${registro.nombre}</td>
                <td class="text-center centerialize" style="background-color: #75b55e; color: white;">${registro.dni}</td>
                <td class="text-center centerialize hidden">${registro.mesa}</td>
                <td class="text-center centerialize hidden">${registro.votacion}</td>
                </tr>`;
            }else{
                return `<tr class='selectMe' id='${registro.id}'>
                <td class="text-center centerialize">${registro.id}</td>
                <td class="text-center centerialize">${registro.apellido}</td>
                <td class="text-center centerialize">${registro.nombre}</td>
                <td class="text-center centerialize">${registro.dni}</td>
                <td class="text-center centerialize hidden">${registro.mesa}</td>
                <td class="text-center centerialize hidden">${registro.votacion}</td>
                </tr>`
            }
            
        })
        .join('');
    regListID.innerHTML = htmlString;
};

const on = (element, event, selector, handler) => {
    element.addEventListener(event, e => {
        if(e.target.closest(selector)){
            handler(e)
        }
    })
}

function startLiveUpdate () {
    setInterval(function () {
        if (searchBar.value=='' && btnTodos.disabled==true){
            cargarVotantes();
        }
    }, 150000)
}


cargarVotantes();
document.addEventListener('DOMContentLoaded', () => {
    startLiveUpdate()
})