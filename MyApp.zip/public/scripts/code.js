//Definición de variables
let mesaNumero = document.getElementById('mesaNumber').innerHTML
const url = `http://18.191.60.88/api/mesa${mesaNumero}/`
const regList = document.querySelector('tbody');
const searchBar = document.getElementById('searchBar');
const btnTodos = document.getElementById('btnTodos')
const btnVotaron = document.getElementById('btnVotaron')
const btnNoVotaron = document.getElementById('btnNoVotaron')
let votantes = [];

const modalRegistro = new bootstrap.Modal(document.getElementById('modalRegistro'))
const formRegistro = document.querySelector('form')
const nombre = document.getElementById('registroNombre')
const apellido = document.getElementById('registroApellido')
const dni = document.getElementById('registroDni')
const mesa = document.getElementById('registroMesa')
const votacion = document.getElementById('registroVotacion')
let opcion = ''

//Función de búsqueda
searchBar.addEventListener('keyup', (e) => {
    btnTodos.disabled = false
    btnNoVotaron.disabled = false
    btnVotaron.disabled = false
    const searchString = e.target.value.toLowerCase();
    if(searchString==''){
        btnTodos.disabled = true
    }

    const votantesFiltrados = votantes.filter((votante) => {
        const votanteNombreCompleto = votante.apellido+' '+votante.nombre+' '+votante.dni
        return (
            votanteNombreCompleto.toLowerCase().includes(searchString)
        );
    });
    mostrar(votantesFiltrados);
});


//Función de filtrado (botones)
btnTodos.addEventListener('click', (e) => {
    btnTodos.disabled = true
    btnNoVotaron.disabled = false
    btnVotaron.disabled = false
    searchBar.value=''
    const votantesFiltrados = votantes.filter((votante) => {
        return (
            votante.votacion==0 ||
            votante.votacion==1
        );
    });
    mostrar(votantesFiltrados);
});

btnVotaron.addEventListener('click', (e) => {
    btnTodos.disabled = false
    btnNoVotaron.disabled = false
    btnVotaron.disabled = true
    searchBar.value=''
    const votantesFiltrados = votantes.filter((votante) => {
        return (
            votante.votacion==1
        );
    });
    mostrar(votantesFiltrados);
});

btnNoVotaron.addEventListener('click', (e) => {
    btnTodos.disabled = false
    btnNoVotaron.disabled = true
    btnVotaron.disabled = false
    searchBar.value=''
    const votantesFiltrados = votantes.filter((votante) => {
        return (
            votante.votacion==0
        );
    });
    mostrar(votantesFiltrados);
});

//Función para cargar los votantes
const cargarVotantes = async () => {
    try {
        const res = await fetch(url);
        votantes = await res.json();
        mostrar(votantes);
    } catch (err) {
        console.error(err);
    }
};





btnCrear.addEventListener('click', () => {
    let mesasa = document.getElementById('mesaNumber').innerHTML
    let mesaNumero = parseInt(mesasa)
    nombre.value = ''
    apellido.value = ''
    dni.value = ''
    mesa.value = mesaNumero
    votacion.value=0
    modalRegistro.show()
    opcion = 'crear'
})

//Función para mostrar los resultados
const mostrar = (registros) => {
    const htmlString = registros
        .map((registro) => {
            if(registro.votacion==1) {
                return `
                <tr class='selectMe' id='${registro.id}'>
                <td class="text-center centerialize" style="background-color: #75b55e; color: white; padding: 1px;">${registro.id}</td>
                <td class="text-center centerialize" style="background-color: #75b55e; color: white; padding: 1px;">${registro.apellido}</td>
                <td class="text-center centerialize" style="background-color: #75b55e; color: white; padding: 1px;">${registro.nombre}</td>
                <td class="text-center centerialize" style="background-color: #75b55e; color: white; padding: 1px 5px">${registro.dni}</td>
                <td class="text-center centerialize hidden">${registro.mesa}</td>
                <td class="text-center centerialize hidden">${registro.votacion}</td>
                <td class="text-center"><a class="btnBorrar btn btn-danger">X</a></td>
                </tr>`;
            }else{
                return `<tr class='selectMe' id='${registro.id}'>
                <td class="text-center centerialize" style="padding: 1px;">${registro.id}</td>
                <td class="text-center centerialize" style="padding: 1px;">${registro.apellido}</td>
                <td class="text-center centerialize" style="padding: 1px;">${registro.nombre}</td>
                <td class="text-center centerialize" style="padding: 1px 5px">${registro.dni}</td>
                <td class="text-center centerialize hidden">${registro.mesa}</td>
                <td class="text-center centerialize hidden">${registro.votacion}</td>
                <td class="text-center"><a class="btnEditar btn btn-primary">✓</a></td>
                </tr>`
            }
        })
        .join('');
    regList.innerHTML = htmlString;
};

const cargarData = async () => {
    try {
        const res = await fetch(`http://18.191.60.88/api/mesas/${mesaNumero}`);
        dataCargada = await res.json();
        if(dataCargada[0].estado == 0) {
            cargarVotantes();
        } else if(dataCargada[0].estado == 1) {
            let body = document.querySelector('body')
            body.innerHTML = `
            <div id="mesaNumber" class="hidden">${mesaNumero}</div>
            <div class='container text-center' style='color: white; margin-top: 2rem;'>
                <h1 style='color: #db0000;'>MESA ${mesaNumero} CERRADA</h1>
                <br>
                <br>
                <button id="btnVotos" type="button" class="btn btn-primary" data-bs-toggle="modal">Enviar Recuento de Votos</button>
                <br>
                <br>
                <br>
                <a style='text-decoration: none; color: white; font-size: 2rem;' href='/links'>Links</a>
            </div>



            <div class="modal fade" id="modalData" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-primary text-white">
                            <h5 class="modal-title" id="exampleModalLabel">Enviar Votos</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                    <div class="modal-body">
                        <form>
                            <div class="mb-1">
                                <label for="votosFDT" class="col-form-label">Frente de Todos:</label>
                                <input type="number" class="form-control" id="votosFDT">
                            </div>
                            <div class="mb-1">
                                <label for="votosJXC" class="col-form-label">Juntos por el Cambio:</label>
                                <input type="number" class="form-control" id="votosJXC">
                            </div>
                            <div class="mb-1">
                                <label for="votosAL" class="col-form-label">Alternativa Legítima:</label>
                                <input type="number" class="form-control" id="votosAL">
                            </div>
                            <div class="mb-1">
                                <label for="votosBlanco" class="col-form-label">Votos en Blanco:</label>
                                <input type="number" class="form-control" id="votosBlanco">
                            </div>
                            <div class="mb-1">
                                <label for="votosNulo" class="col-form-label">Votos Nulos:</label>
                                <input type="number" class="form-control" id="votosNulo">
                            </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                                <button id="btnVotosEnviar" type="button" class="btn btn-primary">Enviar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


            <!-- Bootstrap CDN -->
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
            <!-- AlertifyJs CDN -->
            <script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
            <!-- Custom Javascript -->
            <script src="resources/scripts/code.js"></script>
            `
            const modalData = new bootstrap.Modal(document.getElementById('modalData'))
            const votosFDT = document.getElementById('votosFDT')
            const votosJXC = document.getElementById('votosJXC')
            const votosAL = document.getElementById('votosAL')
            const votosBlanco = document.getElementById('votosBlanco')
            const votosNulo = document.getElementById('votosNulo')
            btnVotos.addEventListener('click', () => {
                votosFDT.value = ''
                votosJXC.value = ''
                votosAL.value = ''
                votosBlanco.value = ''
                votosNulo.value = ''
                modalData.show()
            })
            btnVotosEnviar.addEventListener('click', (e) => {
                e.preventDefault()
                fetch(`http://18.191.60.88/api/mesas/${mesaNumero}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        votosfdt:votosFDT.value,
                        votosjuntos:votosJXC.value,
                        votosalternativa:votosAL.value,
                        votosblanco:votosBlanco.value,
                        votosnulo:votosNulo.value
                    })
                })
                .then( response => response.json() )
                .then( response => location.reload())
                modalData.hide()
            })
        } else {
            let body = document.querySelector('body')
            body.innerHTML = `
            <div id="mesaNumber" class="hidden">${mesaNumero}</div>
            <div class='container text-center' style='color: white; margin-top: 2rem;'>
                <h1 style='color: #db0000;'>MESA ${mesaNumero} CERRADA</h1>
                <br>
                <h1 style='color: #00d60e;'>DATOS ENVIADOS</h1>
                <br>
                <br>
                <button id="btnVotos" type="button" class="btn btn-primary" data-bs-toggle="modal">Editar Recuento de Votos</button>
                <br>
                <br>
                <br>
                <a style='text-decoration: none; color: white; font-size: 2rem;' href='/links'>Links</a>
            </div>



            <div class="modal fade" id="modalData" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-primary text-white">
                            <h5 class="modal-title" id="exampleModalLabel">Enviar Votos</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                    <div class="modal-body">
                        <form>
                            <div class="mb-1">
                                <label for="votosFDT" class="col-form-label">Frente de Todos:</label>
                                <input type="number" class="form-control" id="votosFDT">
                            </div>
                            <div class="mb-1">
                                <label for="votosJXC" class="col-form-label">Juntos por el Cambio:</label>
                                <input type="number" class="form-control" id="votosJXC">
                            </div>
                            <div class="mb-1">
                                <label for="votosAL" class="col-form-label">Alternativa Legítima:</label>
                                <input type="number" class="form-control" id="votosAL">
                            </div>
                            <div class="mb-1">
                                <label for="votosBlanco" class="col-form-label">Votos en Blanco:</label>
                                <input type="number" class="form-control" id="votosBlanco">
                            </div>
                            <div class="mb-1">
                                <label for="votosNulo" class="col-form-label">Votos Nulos:</label>
                                <input type="number" class="form-control" id="votosNulo">
                            </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                                <button id="btnVotosEnviar" type="button" class="btn btn-primary">Enviar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


            <!-- Bootstrap CDN -->
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
            <!-- AlertifyJs CDN -->
            <script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
            <!-- Custom Javascript -->
            <script src="resources/scripts/code.js"></script>
            `
            const modalData = new bootstrap.Modal(document.getElementById('modalData'))
            const formVotos = document.querySelector('form')
            const votosFDT = document.getElementById('votosFDT')
            const votosJXC = document.getElementById('votosJXC')
            const votosAL = document.getElementById('votosAL')
            const votosBlanco = document.getElementById('votosBlanco')
            const votosNulo = document.getElementById('votosNulo')
            btnVotos.addEventListener('click', () => {
                votosFDT.value = dataCargada[0].votosfdt
                votosJXC.value = dataCargada[0].votosjuntos
                votosAL.value = dataCargada[0].votosalternativa
                votosBlanco.value = dataCargada[0].votosblanco
                votosNulo.value = dataCargada[0].votosnulo
                modalData.show()
            })
            btnVotosEnviar.addEventListener('click', (e) => {
                e.preventDefault()
                fetch(`http://18.191.60.88/api/mesas/${mesaNumero}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        votosfdt:votosFDT.value,
                        votosjuntos:votosJXC.value,
                        votosalternativa:votosAL.value,
                        votosblanco:votosBlanco.value,
                        votosnulo:votosNulo.value
                    })
                })
                .then( response => response.json() )
                .then( response => location.reload())
                modalData.hide()
            })
        }
    } catch (err) {
        console.log(err)
    }
}
cargarData()


const on = (element, event, selector, handler) => {
    element.addEventListener(event, e => {
        if(e.target.closest(selector)){
            handler(e)
        }
    })
}

//Procedimiento Cancelar Votación
on(document, 'click', '.btnBorrar', e => {
    const row = e.target.parentNode.parentNode
    const id = row.children[0].innerHTML
    const apellidoForm = row.children[1].innerHTML
    const nombreForm = row.children[2].innerHTML
    const dniForm = row.children[3].innerHTML
    const mesaForm = row.children[4].innerHTML
    const votacionForm = 0
    alertify.confirm(`Desea deshacer la votación de ${apellidoForm}, ${nombreForm}?`,
    function(){
        fetch(url+id, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                apellido:apellidoForm,
                nombre:nombreForm,
                dni:dniForm,
                mesa:mesaForm,
                votacion:votacionForm
            })
        })
        .then( response => response.json() )
        .then( response => location.reload())
        //alertify.success('Ok');
    },
    function(){
        //alertify.error('Cancel');
    });
})

//Procedimiento Editar
let idForm = 0
on(document, 'click', '.btnEditar', e => {
    const row = e.target.parentNode.parentNode
    idForm = row.children[0].innerHTML
    const apellidoForm = row.children[1].innerHTML
    const nombreForm = row.children[2].innerHTML
    const dniForm = row.children[3].innerHTML
    const mesaForm = row.children[4].innerHTML
    const votacionForm = 1
    fetch(url+idForm, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            apellido:apellidoForm,
            nombre:nombreForm,
            dni:dniForm,
            mesa:mesaForm,
            votacion:votacionForm
        })
    })
    .then( response => response.json() )
    .then( response => location.reload())
})


//Procedimiento Crear y/o Editar
formRegistro.addEventListener('submit', (e) => {
    e.preventDefault()
    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            apellido:apellido.value,
            nombre:nombre.value,
            dni:dni.value,
            mesa:mesa.value,
            votacion:votacion.value
        })
    })
    .then( response => response.json())
    .then( data => {
        const nuevoRegistro = []
        nuevoRegistro.push(data)
        location.reload()
    })
    }
)


//Cerrar Mesa
closeTableURL = 'http://18.191.60.88/api/mesas/cerrar/'
on(document, 'click', '.btnCerrar', e => {
    alertify.confirm(`DESEA CERRAR LA MESA ${mesaNumero}?`,
    function(){
        fetch(closeTableURL+mesaNumero, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                estado:1
            })
        })
        .then( response => response.json() )
        .then( response => location.reload())
        //alertify.success('Ok');
    },
    function(){
        //alertify.error('Cancel');
    });
})